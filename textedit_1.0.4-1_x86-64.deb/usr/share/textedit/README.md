# TextEdit
TextEdit je jednoduchý poznámkový blok využívající knihovny GTK+. Je naprogramován v Jazyce Python.

# Ukázka Programu

![Ukázka Programu](https://github.com/vikdevelop/textedit/blob/main/src/img/textedit.png)

# Instalace
Pro instalaci je nutné mít nainstalovanou Python 3.
1. Naklonujte tento repositář:
```
git clone https://github.com/vikdevelop/textedit.git
```
2. Přejděte do adresáře a spusťtě aplikaci 
```
 cd ./textedit/src && python -m textedit.py
 ```
